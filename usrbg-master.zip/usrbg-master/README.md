<h1 align="center">USRBG</h1>
<p align="center">A database of custom user requested backgrounds.</p>

<p align="center"><img height="400" align="center" src="https://i.imgur.com/HaFW8J6.png"></p>

## Request your own USRBG
* Join this Discord Server > [Black Box](https://discord.gg/TeRQEPb), follow the instructions located in [#background-request](https://discord.com/channels/449175561529589761/645627516794699787/).

**All requests are processed manually** by a select few theme developers (as of right now). You should expect to **wait a decent amount of time before** your background **is added.**
